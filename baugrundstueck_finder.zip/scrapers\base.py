from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

@dataclass
class ListingItem:
    title: str
    link: str
    source: str
    category: str # "Land", "Auction", "DeepSearch-Tender", "DeepSearch-BPlan"
    location: str
    price: str = "N/D"
    area_sqm: str = "N/D"
    train_info: str = ""
    details: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.title,
            "link": self.link,
            "source": self.source,
            "category": self.category,
            "location": self.location,
            "price": self.price,
            "area_sqm": self.area_sqm,
            "train_info": self.train_info,
            "details": self.details,
        }

class BaseScraper(ABC):
    def __init__(self, settings: Dict[str, Any]):
        self.settings = settings
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
        }

    @abstractmethod
    def fetch_listings(self) -> List[ListingItem]:
        """Esegue il recupero e restituisce una lista di ListingItem."""
        pass

    def determine_train_connection(self, text: str) -> str:
        """
        Riconosce la vicinanza a stazioni o linee ferroviarie dirette verso Francoforte.
        - Schöneck (Kilianstädten, Büdesheim, Oberdorfelden): RB 34 diretta a Bad Vilbel / Frankfurt Hbf
        - Nidderau (Windecken, Heldenbergen, Ostheim, Erbstadt): RB 34 e RB 49 (Hanau/Friedberg)
        - Bad Vilbel: S-Bahn S6 e RB 34
        - Hanau: S8, S9, RE50, RB58
        """
        text_lower = text.lower()
        
        if "schöneck" in text_lower or "schoneck" in text_lower or "büdesheim" in text_lower or "kilianstädten" in text_lower or "oberdorfelden" in text_lower:
            return "RB34 (Niddertalbahn -> Bad Vilbel / Frankfurt Hbf)"
        
        if "nidderau" in text_lower or "windecken" in text_lower or "heldenbergen" in text_lower or "ostheim" in text_lower:
            return "RB34 (diretto per Frankfurt Hbf) & RB49 (verso Hanau/Friedberg)"
            
        if "bad vilbel" in text_lower:
            return "S-Bahn S6 (15 min da Frankfurt Hbf) & RB34"
            
        if "karben" in text_lower:
            return "S-Bahn S6 (verso Frankfurt Hbf)"
            
        if "hanau" in text_lower:
            return "S8 / S9 / RE50 (veloce per Frankfurt Hbf/Süd)"
            
        if "maintal" in text_lower:
            return "RB58 / RE54 (verso Frankfurt Hbf/Süd)"
            
        return "Linea pendolare circondario Francoforte"
